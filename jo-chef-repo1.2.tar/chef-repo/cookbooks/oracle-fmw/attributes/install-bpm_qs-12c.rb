default['bpm_qs-12c']['version'] = "12.1.3"
default['bpm_qs-12c']['url'] = "https://b8fa6f.compute-usoracleus34248.oraclecloud.internal/files/fmw_#{node['bpm_qs-12c']['version']}.0.0_bpmqs_Disk1_1of1.zip"
default['bpm_qs-12c']['download_loc'] = "https://b8fa6f.compute-usoracleus34248.oraclecloud.internal/files/"

default['bpm_qs_12c']['bpm_suite_source_file']            ='fmw_12.1.3.0.0_soa.jar'

default['bpm_qs_12c']['bpm_suite_source_2_file']            ='fmw_12.2.1.1.0_bpm_quickstart2.jar'
# default['bpm_qs-12c']['checksum'] = "dc0270122d52"
