oracle_fmw CHANGELOG
====================

This file is used to list changes made in each version of the oracle_fmw cookbook.

0.1.0
-----
- [jeqo] - Initial release of oracle_fmw.

0.1.1
-----
- [jeqo] - Adding documentation.


0.2.0
-----
- [jeqo] - SOA Suite 12c support
- [jeqo] - Oracle Fusion Middleware 11g support (SOA, BPM, OSB) 
