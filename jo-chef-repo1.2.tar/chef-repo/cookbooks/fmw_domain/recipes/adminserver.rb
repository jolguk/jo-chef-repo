#
# Cookbook Name:: fmw_domain
# Recipe:: adminserver
#
# Copyright 2015 Oracle. All Rights Reserved
#
# log  "####{cookbook_name}::#{recipe_name} #{Time.now.inspect}: Starting execution phase"
puts "####{cookbook_name}::#{recipe_name} #{Time.now.inspect}: Starting compile phase"

#fail 'databag_key parameter cannot be empty' unless node['fmw_domain'].attribute?('databag_key')

include_recipe 'fmw_domain::nodemanager'

#node['fmw_domain'] =  begin
#                data_bag_item('fmw_domains',node['fmw_domain']['databag_key'])
#              rescue Net::HTTPServerException, Chef::Exceptions::ValidationFailed, Chef::Exceptions::InvalidDataBagPath
#                [] # empty array for length comparison
#              end
#node['fmw_domain'] = node['fmw_domain'].to_hash if node['fmw_domain'].instance_of? Chef::EncryptedDataBagItem


if node['os'].include?('windows')

  if VERSION.start_with? '11.'
    ruby_block "loading for chef 11 adminserver" do
      block do
        res = Chef::Resource::Chef::Resource::FmwDomainAdminserverWindows.new('adminserver', run_context )
        res.domain_dir                 "#{node['fmw_domain']['domains_dir']}/#{node['fmw_domain']['domain_name']}"
        res.domain_name                node['fmw_domain']['domain_name']
        res.adminserver_name           node['fmw_domain']['adminserver_name']
        res.weblogic_home_dir          node['fmw']['weblogic_home_dir']
        res.java_home_dir              node['fmw']['java_home_dir']
        res.weblogic_user              node['fmw_domain']['weblogic_user']
        res.weblogic_password          node['fmw_domain']['weblogic_password']
        res.nodemanager_listen_address node['fmw_domain']['nodemanager_listen_address']
        res.nodemanager_port           node['fmw_domain']['nodemanager_port']
        res.run_action                 :start
      end
    end
  else
    fmw_domain_adminserver 'adminserver' do
      action                     :start
      domain_dir                 "#{node['fmw_domain']['domains_dir']}/#{node['fmw_domain']['domain_name']}"
      domain_name                node['fmw_domain']['domain_name']
      adminserver_name           node['fmw_domain']['adminserver_name']
      weblogic_home_dir          node['fmw']['weblogic_home_dir']
      java_home_dir              node['fmw']['java_home_dir']
      weblogic_user              node['fmw_domain']['weblogic_user']
      weblogic_password          node['fmw_domain']['weblogic_password']
      nodemanager_listen_address node['fmw_domain']['nodemanager_listen_address']
      nodemanager_port           node['fmw_domain']['nodemanager_port']
    end
  end
else
  if VERSION.start_with? '11.'
    ruby_block "loading for chef 11 adminserver" do
      block do
        res = Chef::Resource::Chef::Resource::FmwDomainAdminserverLinux.new('adminserver', run_context )   if node['os'].include?('linux')
        res = Chef::Resource::Chef::Resource::FmwDomainAdminserverSolaris.new('adminserver', run_context ) if node['os'].include?('solaris2')
        res.domain_dir                 "#{node['fmw_domain']['domains_dir']}/#{node['fmw_domain']['domain_name']}"
        res.domain_name                node['fmw_domain']['domain_name']
        res.adminserver_name           node['fmw_domain']['adminserver_name']
        res.weblogic_home_dir          node['fmw']['weblogic_home_dir']
        res.java_home_dir              node['fmw']['java_home_dir']
        res.weblogic_user              node['fmw_domain']['weblogic_user']
        res.weblogic_password          node['fmw_domain']['weblogic_password']
        res.nodemanager_listen_address node['fmw_domain']['nodemanager_listen_address']
        res.nodemanager_port           node['fmw_domain']['nodemanager_port']
        res.os_user                    node['fmw']['os_user']
        res.run_action                 :start
      end
    end
  else
    fmw_domain_adminserver 'adminserver' do
      action                     :start
      domain_dir                 "#{node['fmw_domain']['domains_dir']}/#{node['fmw_domain']['domain_name']}"
      domain_name                node['fmw_domain']['domain_name']
      adminserver_name           node['fmw_domain']['adminserver_name']
      weblogic_home_dir          node['fmw']['weblogic_home_dir']
      os_user                    node['fmw']['os_user']
      java_home_dir              node['fmw']['java_home_dir']
      weblogic_user              node['fmw_domain']['weblogic_user']
      weblogic_password          node['fmw_domain']['weblogic_password']
      nodemanager_listen_address node['fmw_domain']['nodemanager_listen_address']
      nodemanager_port           node['fmw_domain']['nodemanager_port']
    end
  end
end
# log  "####{cookbook_name}::#{recipe_name} #{Time.now.inspect}: Finished execution phase"
puts "####{cookbook_name}::#{recipe_name} #{Time.now.inspect}: Finished compile phase"
