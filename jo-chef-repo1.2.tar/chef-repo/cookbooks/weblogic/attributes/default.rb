default['oracle']['user']                                    = 'oracle'
default['oracle']['user_home']                               = '/home/oracle'
default['oracle']['group']                                   = 'oracle'
default['oracle']['beahome']                                 = '/u04/oracle/mw'
default['oracle']['stg']                                     = '/u04/oracle'
default['oracle']['installers']                              = '/u04/oracle/Installers'

default['oracle']['java_installer']                           = 'jdk-6u45-linux-x64.bin'
default['oracle']['java_install_dir']                         = '/u04/oracle/mw/jdk6'

default['oracle']['domain_home']                             ='/u04/oracle/mw/user_projects/domains'
default['oracle']['domain_name']                             = 'infradyn6'
default['oracle']['wls_install_dir']                         = '/u04/oracle/mw/wlserver'
default['oracle']['response_file']                         = 'wls.response'

default['oracle']['admin_user']                              = 'weblogic'
default['oracle']['admin_pass']                              = 'welcome1'
default['oracle']['admin_port']                           = 9211
default['oracle']['listen_port']                          = 9211
default['oracle']['install_node_manager_service']            = 'yes'
default['oracle']['nodemgr_port']                            = 5776
#default['oracle']['local_jvms']                              = '/u04/oracle/mw/jdk1.6.0_45'
default['oracle']['local_jvms']                              = '/usr/lib/jvm/java-1.7.0'
default['oracle']['bea_bundled_jvms']                        = []
default['oracle']['wls_installer']                           = 'server103_linux32.bin'
default['oracle']['download_loc']                            = 'https://b8fa6f.compute-usoracleus34248.oraclecloud.internal/files/'
default['oracle']['wls_generic_installer']                   = 'fmw_12.2.1.0.0_wls.jar'
default['oracle']['wls_infra_installer']                   = 'fmw_12.1.3.0.0_infrastructure.jar'
default['oracle']['wls_bin_installer']                       = 'server103_linux32.bin'
default['oracle']['install_type']                            = 'Fusion Middleware Infrastructure'

default['oracle']['unicast_patch']                           = 'p12822180_1036_Generic.zip'
default['oracle']['bsu_patch']                               = 'p12426828_1035_Generic.zip'
default['oracle']['patchlist']                               = 'YJI2'

default['oracle']['managed_server']['name']                  = 'ms1'
default['oracle']['managed_server']['port']                  = 8003

default['oracle']['template_name']			= 'infradyn6_template'

default['oracle']['weblogic_plugin_enabled']		= 'true'
default['oracle']['accept_backlog']			 = 1024
default['oracle']['autokill_if_failed']			 = 'true'
default['oracle']['overload_protection']		 = 'dyn_protection'
default['oracle']['failure_action']			= 'force-shutdown'
default['oracle']['panic_action'] 			= 'system-exit'


default['oracle']['cluster']                                 = 'democluster'
default['oracle']['dynamiccluster']                                 = 'dynamic_cluster'
default['oracle']['cluster_messaging_mode']			= 'unicast'
default['oracle']['maximum_dynamic_server_count'] 		= 4
default['oracle']['calculated_listen_ports']			='true'
default['oracle']['calculated_machine_names']                     ='true'
default['oracle']['server_name_prefix']                     ='dyn'
default['oracle']['cluster_type']                                 = 'dynamic_cluster'
default['oracle']['dyn_server_name']                                 = 'dynamic_cluster'




default['oracle']['datasource']['name']                      = 'demo-ds'
default['oracle']['datasource']['driver']                    = 'oracle.jdbc.xa.client.OracleXADataSource'
default['oracle']['datasource']['dbhost']                    = 'c90b84'
default['oracle']['datasource']['dbport']                    = 1521
default['oracle']['datasource']['dbsid']                     = 'orcl'
default['oracle']['datasource']['dbusername']                = 'system'
default['oracle']['datasource']['dbpassword']                = 'Welcome1'
default['oracle']['datasource']['target']                    = 'democluster'
