
default['fmw']['version']                 = '12.1.3' # 10.3.6|12.1.1|12.1.2|12.1.3|12.2.1
default['fmw_wls']['install_type']        = 'infra' # infra or wls
default['fmw_wls']['source_file']        = '/var/www/files/fmw_12.2.1.0.0_wls.jar.zip'
default['fmw']['repository_database_url']  = 'jdbc:oracle:thin:@c90b84.compute-usoracleus34248.oraclecloud.internal:1521/orcl'
default['fmw']['repository_password'] = 'Welcome1'
default['fmw']['repository_prefix'] = 'DEV13'
default['fmw']['oracle_common'] = '/u04/oracle/mw/oracle_common'
default['fmw']['time_zone'] = 'America/New_York'

if platform_family?('windows')
  default['fmw']['middleware_home_dir']   = 'C:/oracle/middleware'
  default['fmw']['ora_inventory_dir']     = 'C:\\Program Files\\Oracle\\Inventory'
  default['fmw']['tmp_dir']               = 'C:/temp'
else
  default['fmw']['middleware_home_dir']   = '/u04/oracle/mw'
  default['fmw']['java_home_dir']   = '/usr/lib/jvm/java-1.7.0'
  default['fmw']['weblogic_home_dir']   = '/u04/oracle/mw/wlserver'
  default['fmw']['os_user']               = 'oracle'
  default['fmw']['os_group']              = 'oracle'
  default['fmw']['os_shell']              = '/bin/bash'
end

case platform_family
when 'debian', 'rhel'
  default['fmw']['orainst_dir']       = '/home/oracle'
  default['fmw']['user_home_dir']     = '/home'
  default['fmw']['ora_inventory_dir'] = '/home/oracle/oraInventory'
  default['fmw']['tmp_dir']           = '/u04/tmp'
  default['fmw']['tmp_soa']           = '/tmp/soa_suite'
  default['fmw']['tmp_bpm']           = '/mnt/store/oracle/bpm'

when 'solaris2'
  default['fmw']['orainst_dir']       = '/var/opt/oracle'
  default['fmw']['user_home_dir']     = '/export/home'
  default['fmw']['ora_inventory_dir'] = '/export/home/oracle/oraInventory'
  default['fmw']['tmp_dir']           = '/var/tmp'
end
