Vagrant.configure(2) do |config|
  config.vm.boot_timeout=10000
end
