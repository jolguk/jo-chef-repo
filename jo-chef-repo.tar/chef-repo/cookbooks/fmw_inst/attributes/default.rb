include_attribute 'fmw_wls'

default['fmw_wls']['source_file']            ='/var/www/files/fmw_12.1.3.0.0_infrastructure.jar'

default['fmw']['java_home_dir']       = '/usr/lib/jvm/java-1.7.0'

default['fmw']['middleware_home_dir']       = '/u04/oracle/mw'

default['fmw']['version']            ='12.1.3'

default['fmw_jdk']['source_file']            ='/home/oracle/jdk-8u65-linux-x64.tar.gz'

default['fmw_inst']['soa_suite_source_file']            ='fmw_12.1.3.0.0_soa.jar'

# default['fmw_inst']['soa_suite_source_2_file']            ='fmw_12.1.3.0.0_soa_quickstart2.jar'

default['fmw_inst']['soa_suite_install_type']            ='BPM'

default['fmw_inst']['bpm_suite_install_type']            ='BPM'

default['fmw_inst']['bpm_suite_source_file']            ='fmw_12.1.3.0.0_bpm_quickstart.jar'

default['fmw_inst']['bpm_suite_source_2_file']            ='fmw_12.1.3.0.0_bpm_quickstart2.jar'

default['fmw_inst']['download_loc']      = 'https://b8fa6f.compute-usoracleus34248.oraclecloud.internal/files/'

default['fmw_inst']['bpm_tmp']           = '/mnt/store/oracle/bpm'

