import sys

execfile('<%= @tmp_dir %>/common.py')

# weblogic node params
WLHOME           = '<%= @weblogic_home_dir %>'
JAVA_HOME        = '<%= @java_home_dir %>'
WEBLOGIC_VERSION = '<%= @version %>'

# domain params
DOMAIN_PATH       = '<%= @domain_dir %>'
DOMAIN            = '<%= @domain_name %>'
APP_PATH          = '<%= @app_dir %>'

# adminserver params
ADMIN_SERVER_NAME           = '<%= @adminserver_name %>'
ADMIN_SERVER_LISTEN_ADDRESS = '<%= @adminserver_listen_address %>'
MACHINE_NAME                = 'LocalMachine'
NODEMANAGER_LISTEN_PORT     = <%= @nodemanager_port %>

SOA_SERVER_STARTUP_ARGUMENTS = '<%= @soa_server_startup_arguments %>'
SOA_SERVER_LISTEN_PORT       = 8001
ESS_CLUSTER                  = '<%= @ess_cluster %>'
SOA_CLUSTER                  = '<%= @soa_cluster %>'
OSB_CLUSTER                  = '<%= @osb_cluster %>'
BAM_CLUSTER                  = '<%= @bam_cluster %>'

# templates
WLS_EM_TEMPLATE        = '<%= @wls_em_template %>'
WLS_JRF_TEMPLATE       = '<%= @wls_jrf_template %>'
WLS_APPL_CORE_TEMPLATE = '<%= @wls_appl_core_template %>'
WLS_WSMPM_TEMPLATE     = '<%= @wls_wsmpm_template %>'
WLS_SOA_TEMPLATE       = '<%= @wls_soa_template %>'
WLS_BPM_TEMPLATE       = '<%= @wls_bpm_template %>'
WLS_B2B_TEMPLATE       = '<%= @wls_b2b_template %>'

# repository
REPOS_DBURL         = '<%= @repository_database_url %>'
REPOS_DBUSER_PREFIX = '<%= @repository_prefix %>'
REPOS_DBPASSWORD    = '<%= @repository_password %>'
TZ                  = '<%= @time_zone %>'
COMMON_COMPONENTS_HOME = '<%= @oracle_common %>'

BPM_ENABLED=<%= @bpm_enabled %>

readDomain(DOMAIN_PATH)

cd('/')
setOption( "AppDir", APP_PATH )

#print 'Adding SOA Template'
addTemplate(WLS_APPL_CORE_TEMPLATE)
print 'WLS Core Added'

#addTemplate(WLS_JRF_TEMPLATE)
print "Probably already added error:", sys.exc_info()[0]

#addTemplate(WLS_WSMPM_TEMPLATE)
print "Probably already added error:", sys.exc_info()[0]

addTemplate(WLS_SOA_TEMPLATE)
print 'SOA template added'

#if BPM_ENABLED == true:
#print 'Adding BPM Template'
#addTemplate(WLS_BPM_TEMPLATE)





cd('/JDBCSystemResource/LocalSvcTblDataSource/JdbcResource/LocalSvcTblDataSource')
cd('JDBCDriverParams/NO_NAME_0')
set('DriverName','oracle.jdbc.OracleDriver')
set('URL','jdbc:oracle:thin:@c90b84:1521/orcl')
set('PasswordEncrypted', 'Welcome1')
cd('Properties/NO_NAME_0')
cd('Property/user')
cmo.setValue('DEV13_STB')

cd('/JDBCSystemResource/mds-owsm/JdbcResource/mds-owsm/JDBCDriverParams/NO_NAME_0')
cmo.setUrl('jdbc:oracle:thin:@c90b84:1521:orcl')
cmo.setDriverName('oracle.jdbc.OracleDriver')
set('UsePasswordIndirection', 'false')
set('UseXADataSourceInterface', 'false')
set('PasswordEncrypted', 'Welcome1')
cd('Properties/NO_NAME/Property/user')
cmo.setValue('DEV13_MDS')



cd('/JDBCSystemResource/mds-soa/JdbcResource/mds-soa/JDBCDriverParams/NO_NAME_0')
cmo.setUrl('jdbc:oracle:thin:@c90b84:1521:orcl')
cmo.setDriverName('oracle.jdbc.OracleDriver')
set('UsePasswordIndirection', 'false')
set('UseXADataSourceInterface', 'false')
set('PasswordEncrypted', 'Welcome1')
cd('Properties/NO_NAME/Property/user')
cmo.setValue('DEV13_MDS')

cd('/JDBCSystemResource/opss-data-source/JdbcResource/opss-data-source/JDBCDriverParams/NO_NAME_0')
cmo.setUrl('jdbc:oracle:thin:@c90b84:1521:orcl')
cmo.setDriverName('oracle.jdbc.OracleDriver')
set('UsePasswordIndirection', 'false')
set('UseXADataSourceInterface', 'false')
set('PasswordEncrypted', 'Welcome1')
cd('Properties/NO_NAME/Property/user')
cmo.setValue('DEV13_OPSS')
cd('/JDBCSystemResource/opss-audit-DBDS/JdbcResource/opss-audit-DBDS/JDBCDriverParams/NO_NAME_0')
cmo.setUrl('jdbc:oracle:thin:@c90b84:1521:orcl')
cmo.setDriverName('oracle.jdbc.OracleDriver')
set('UsePasswordIndirection', 'false')
set('UseXADataSourceInterface', 'false')
set('PasswordEncrypted', 'Welcome1')
cd('Properties/NO_NAME/Property/user')
cmo.setValue('DEV13_IAU_APPEND')
cd('/JDBCSystemResource/opss-audit-viewDS/JdbcResource/opss-audit-viewDS/JDBCDriverParams/NO_NAME_0')
cmo.setUrl('jdbc:oracle:thin:@c90b84:1521:orcl')
cmo.setDriverName('oracle.jdbc.OracleDriver')
set('UsePasswordIndirection', 'false')
set('UseXADataSourceInterface', 'false')
set('PasswordEncrypted', 'Welcome1')
cd('Properties/NO_NAME/Property/user')
cmo.setValue('DEV13_IAU_VIEWER')

#cd('/')
# destroy the normal one

print 'Change AdminServer'
cd('/Servers/'+ADMIN_SERVER_NAME)
set('Machine','LocalMachine')




cd('/JDBCSystemResource/SOALocalTxDataSource/JdbcResource/SOALocalTxDataSource/JDBCDriverParams/NO_NAME_0')
cmo.setUrl('jdbc:oracle:thin:@c90b84:1521:orcl')
cmo.setDriverName('oracle.jdbc.OracleDriver')
set('UsePasswordIndirection', 'false')
set('UseXADataSourceInterface', 'false')
set('PasswordEncrypted', 'Welcome1')
cd('Properties/NO_NAME/Property/user')
cmo.setValue('DEV13_SOAINFRA')

cd('/JDBCSystemResource/OraSDPMDataSource/JdbcResource/OraSDPMDataSource/JDBCDriverParams/NO_NAME_0')
cmo.setUrl('jdbc:oracle:thin:@c90b84:1521:orcl')
cmo.setDriverName('oracle.jdbc.OracleDriver')
set('UsePasswordIndirection', 'false')
set('UseXADataSourceInterface', 'false')
set('PasswordEncrypted', 'Welcome1')
cd('Properties/NO_NAME/Property/user')
cmo.setValue('DEV13_UMS')

cd('/JDBCSystemResource/EDNDataSource/JdbcResource/EDNDataSource/JDBCDriverParams/NO_NAME_0')
cmo.setUrl('jdbc:oracle:thin:@c90b84:1521:orcl')
cmo.setDriverName('oracle.jdbc.OracleDriver')
set('UsePasswordIndirection', 'false')
set('UseXADataSourceInterface', 'false')
set('PasswordEncrypted', 'Welcome1')
cd('Properties/NO_NAME/Property/user')
cmo.setValue('DEV13_SOAINFRA')

cd('/JDBCSystemResource/EDNLocalTxDataSource/JdbcResource/EDNLocalTxDataSource/JDBCDriverParams/NO_NAME_0')
cmo.setUrl('jdbc:oracle:thin:@c90b84:1521:orcl')
cmo.setDriverName('oracle.jdbc.OracleDriver')
set('UsePasswordIndirection', 'false')
set('UseXADataSourceInterface', 'false')
set('PasswordEncrypted', 'Welcome1')
cd('Properties/NO_NAME/Property/user')
cmo.setValue('DEV13_SOAINFRA')

cd('/JDBCSystemResource/SOADataSource/JdbcResource/SOADataSource/JDBCDriverParams/NO_NAME_0')
cmo.setUrl('jdbc:oracle:thin:@c90b84:1521:orcl')
cmo.setDriverName('oracle.jdbc.OracleDriver')
set('UsePasswordIndirection', 'false')
set('UseXADataSourceInterface', 'false')
set('PasswordEncrypted', 'Welcome1')
cd('Properties/NO_NAME/Property/user')
cmo.setValue('DEV13_SOAINFRA')


cd('/JDBCSystemResources/EDNDataSource/JdbcResource/EDNDataSource/JDBCDriverParams/NO_NAME_0')
set('PasswordEncrypted', 'Welcome1')
cmo.setUrl('jdbc:oracle:thin:@c90b84:1521/orcl')

cd('/JDBCSystemResources/EDNDataSource/JdbcResource/EDNDataSource/JDBCDriverParams/NO_NAME_0/Properties/NO_NAME_0/Property/user')
cmo.setValue('DEV13_SOAINFRA')

cd('/JDBCSystemResources/EDNDataSource/JdbcResource/EDNDataSource/JDBCDriverParams/NO_NAME_0/Properties/NO_NAME_0/Property/oracle.net.CONNECT_TIMEOUT')
cmo.setValue('10000')



cd('/JDBCSystemResources/EDNLocalTxDataSource/JdbcResource/EDNLocalTxDataSource/JDBCDriverParams/NO_NAME_0')
set('PasswordEncrypted', 'Welcome1')
cmo.setUrl('jdbc:oracle:thin:@c90b84:1521/orcl')

cd('/JDBCSystemResources/EDNLocalTxDataSource/JdbcResource/EDNLocalTxDataSource/JDBCDriverParams/NO_NAME_0/Properties/NO_NAME_0/Property/user')
cmo.setValue('DEV13_SOAINFRA')

cd('/JDBCSystemResources/EDNLocalTxDataSource/JdbcResource/EDNLocalTxDataSource/JDBCDriverParams/NO_NAME_0/Properties/NO_NAME_0/Property/oracle.net.CONNECT_TIMEOUT')
cmo.setValue('10000')



cd('/JDBCSystemResources/OraSDPMDataSource/JdbcResource/OraSDPMDataSource/JDBCDriverParams/NO_NAME_0')
set('PasswordEncrypted', 'Welcome1')
cmo.setUrl('jdbc:oracle:thin:@c90b84:1521/orcl')

cd('/JDBCSystemResources/OraSDPMDataSource/JdbcResource/OraSDPMDataSource/JDBCDriverParams/NO_NAME_0/Properties/NO_NAME_0/Property/SendStreamAsBlob')
cmo.setValue('true')

cd('/JDBCSystemResources/OraSDPMDataSource/JdbcResource/OraSDPMDataSource/JDBCDriverParams/NO_NAME_0/Properties/NO_NAME_0/Property/user')
cmo.setValue('DEV13_UMS')

cd('/JDBCSystemResources/OraSDPMDataSource/JdbcResource/OraSDPMDataSource/JDBCDriverParams/NO_NAME_0/Properties/NO_NAME_0/Property/oracle.net.CONNECT_TIMEOUT')
cmo.setValue('10000')



cd('/JDBCSystemResources/SOADataSource/JdbcResource/SOADataSource/JDBCDriverParams/NO_NAME_0')
set('PasswordEncrypted', 'Welcome1')
cmo.setUrl('jdbc:oracle:thin:@c90b84:1521/orcl')

cd('/JDBCSystemResources/SOADataSource/JdbcResource/SOADataSource/JDBCDriverParams/NO_NAME_0/Properties/NO_NAME_0/Property/user')
cmo.setValue('DEV13_SOAINFRA')

cd('/JDBCSystemResources/SOADataSource/JdbcResource/SOADataSource/JDBCDriverParams/NO_NAME_0/Properties/NO_NAME_0/Property/oracle.net.CONNECT_TIMEOUT')
cmo.setValue('10000')



cd('/JDBCSystemResources/SOALocalTxDataSource/JdbcResource/SOALocalTxDataSource/JDBCDriverParams/NO_NAME_0')
set('PasswordEncrypted', 'Welcome1')
cmo.setUrl('jdbc:oracle:thin:@c90b84:1521/orcl')

cd('/JDBCSystemResources/SOALocalTxDataSource/JdbcResource/SOALocalTxDataSource/JDBCDriverParams/NO_NAME_0/Properties/NO_NAME_0/Property/user')
cmo.setValue('DEV13_SOAINFRA')

cd('/JDBCSystemResources/SOALocalTxDataSource/JdbcResource/SOALocalTxDataSource/JDBCDriverParams/NO_NAME_0/Properties/NO_NAME_0/Property/oracle.net.CONNECT_TIMEOUT')
cmo.setValue('10000')




updateDomain()
dumpStack()

closeDomain()
readDomain(DOMAIN_PATH)

cleanJMS('SOAJMSModule', 'SOAJMSServer_auto', 'SOAJMSFileStore_auto')
cleanJMS('UMSJMSSystemResource', 'UMSJMSServer_auto', 'UMSJMSFileStore_auto')
cleanJMS('PS6SOAJMSModule', 'PS6SOAJMSServer_auto', 'PS6SOAJMSFileStore_auto')
cleanJMS('BPMJMSModule', 'BPMJMSServer_auto', 'BPMJMSFileStore_auto')

print 'Create SoaCluster'
cd('/')
create('soa_cluster', 'Cluster')


# soa11g_bpm(SOA_CLUSTER, BPM_ENABLED)
# soa11g_ps6(SOA_CLUSTER)

assign('Server','soa_server1','Cluster','soa_cluster')



getDatabaseDefaults()

changeDatasourceToXA('EDNDataSource')
changeDatasourceToXA('OraSDPMDataSource')
changeDatasourceToXA('SOADataSource')

print 'end datasources'

print 'Add server groups WSM-CACHE-SVR WSMPM-MAN-SVR JRF-MAN-SVR to AdminServer'
serverGroup = ["WSM-CACHE-SVR" , "WSMPM-MAN-SVR" , "JRF-MAN-SVR"]
setServerGroups(ADMIN_SERVER_NAME, serverGroup)                      

print 'Add server group SOA-MGD-SVRS to SoaServer1'
serverGroup = ["SOA-MGD-SVRS"]

setServerGroups('soa_server1', serverGroup)                      



soaServers = getClusterServers('soa_cluster', ADMIN_SERVER_NAME)
cd('/')
print "Add server group SOA-MGD-SVRS to soa_server1" 
setServerGroups('soa_server1' , serverGroup)


updateDomain()
dumpStack()

closeDomain()
readDomain(DOMAIN_PATH)

cleanJMS('UMSJMSSystemResource', 'UMSJMSServer_auto', 'UMSJMSFileStore_auto')
recreateUMSJms12c(ADMIN_SERVER_NAME, 'soa_cluster')


updateDomain()
dumpStack()

closeDomain()

print('Exiting...')
exit()
