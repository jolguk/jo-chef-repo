include_attribute 'fmw_wls'

default['fmw']['java_home_dir']       = '/usr/lib/jvm/java-1.7.0'

default['fmw']['middleware_home_dir']       = '/u04/oracle/mw'

default['fmw']['version']            ='12.2.1'
default['fmw_opatch']['weblogic_patch_id']            ='22505388'
default['fmw_opatch']['weblogic_source_file']            ='/home/oracle/p22505388_122100_Generic.zip'

default['fmw_opatch']['soa_suite_patch_id']            ='22505388'
default['fmw_opatch']['soa_suite_source_file']            ='/home/oracle/p22505388_122100_Generic.zip'

default['fmw_jdk']['source_file']            ='/home/oracle/jdk-8u65-linux-x64.tar.gz'

