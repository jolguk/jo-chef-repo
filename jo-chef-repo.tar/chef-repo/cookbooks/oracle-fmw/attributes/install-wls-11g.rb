default['wls-11g']['installer_file'] = "wls1036_generic.jar"
default['wls-11g']['url'] = "" #"file:///data/oracle-fmw/wls-11g/wls1036_generic.jar"
default['wls-11g']['home_directory'] = "wlserver_10.3"
default['wls-11g']['checksum'] = "0f191ad52f330580ef7baa0656508d98c824c0efaee764aa217b078b0880be10"
