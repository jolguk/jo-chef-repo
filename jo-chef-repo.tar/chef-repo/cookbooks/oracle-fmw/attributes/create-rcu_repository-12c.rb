default['rcu-12c']['oracle_home'] = "/u04/oracle/mw"
default['rcu-12c']['timezone'] = "America/New York"
default['rcu-12c']['db_hostname'] = "c90b84.compute-usoracleus34248.oraclecloud.internal"
default['rcu-12c']['db_port'] = "1521"
default['rcu-12c']['db_service'] = "orcl"
default['rcu-12c']['db_dba_role'] = "sysdba"
default['rcu-12c']['db_dba_user'] = "sys"
default['rcu-12c']['db_dba_password'] = "Welcome1"
default['rcu-12c']['db_schemas_password'] = "Welcome1"
default['rcu-12c']['db_schema_prefix'] = "DEV01"
default['rcu-12c']['components'] = [
	"SOAINFRA",
	"OPSS",
	"IAU",
	"MDS",
	"WLS",
	"UCSUMS",
	"IAU_APPEND",
	"IAU_VIEWER"
]
