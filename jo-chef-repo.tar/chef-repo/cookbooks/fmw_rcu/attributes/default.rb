include_attribute 'fmw_wls'

default['fmw_rcu']['db_sys_user']     = 'sys'
default['fmw_rcu']['rcu_prefix']      = 'DEV13'
#default['fmw_rcu']['databag_key']     = 'dbnode1_DEV1'
default['fmw_rcu']['oracle_home_dir']      = '/u04/oracle/mw/oracle_common'
default['fmw_rcu']['jdbc_database_url']     = 'jdbc:oracle:thin:@c90b84.compute-usoracleus34248.oraclecloud.internal:1521/orcl'
default['fmw_rcu']['db_database_url']      = 'c90b84.compute-usoracleus34248.oraclecloud.internal:1521:orcl'
default['fmw_rcu']['rcu_component_password']      = 'Welcome1'
default['fmw_rcu']['db_sys_password']      = 'Welcome1'



